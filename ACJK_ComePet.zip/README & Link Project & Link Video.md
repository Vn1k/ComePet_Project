# ComePet_Project

 ACJK
 - Amanda Citra Dewanti: 00000066344
 - Calista Belva: 00000067339
 - Jose Andreas Lie: 00000067097
 - Kevin Ken: 00000067060

   
ComePet adalah aplikasi Social Media yang ditujukan untuk mencari dan menyediakan jasa penitipan hewan peliharaan.

terdapat fitur:
- authentication: Sign Up, Log in, Log out, Bording pemilihan activity user (personal use / bersedia melakukan penitipan hewan)
- home: untuk melihat postingan moment dari semua user
- chat: untuk melakukan chat antar followers untuk berbincang mengenai tempat pentipan hewan
- search: untuk mencari user atau tempat penitipan hewan yang tersedia dan terdekat dari user
- post: untuk melakukan share activity foto, dapat melalui capture image dengan camera atau dari gallery, disertai caption, lokasi, dan pet yang terdapat didalam foto tersebut. dapat di upload untuk feeds atau informasi temapt shelter.
- profile: berisikan bio data user, kumpulan postingan user, jenis hewan peliharaan yamg dimiliki, dan lokasi tempat penitipan hewan apabila user bersedia untuk menampung hewan peliharaan, disertai setting user, edit user, dan edit pet.

File Project Android Studio:
https://drive.google.com/file/d/16n9LeJ1Cb08f4Pbpeclh1pNbyqXlR1mO/view?usp=sharing

Video Penjelasan Aplikasi ComePet:
https://drive.google.com/file/d/19K4m0xv7YiFzaNMZRJhtNYapTJVJTdM4/view?usp=sharing